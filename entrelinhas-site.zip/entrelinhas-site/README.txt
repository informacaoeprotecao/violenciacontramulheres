ENTRELINHAS — SITE ESTÁTICO

Publicação gratuita no GitHub Pages:
1. Crie uma conta em https://github.com (se ainda não tiver).
2. Crie um repositório público chamado entrelinhas (sem README automático).
3. Envie o arquivo index.html deste pacote para a raiz do repositório e confirme a alteração.
4. Abra Settings > Pages. Em Build and deployment, selecione Deploy from a branch, branch main e pasta / (root). Salve.
5. Aguarde a publicação. O endereço será https://SEU-USUARIO.github.io/entrelinhas/.

O site é independente do WordPress e funciona com HTML, CSS e JavaScript, sem bibliotecas externas.
Não publique informações pessoais, senhas ou relatos identificáveis no repositório público.
Antes de apresentar/publicar, confira os contatos oficiais e revise o conteúdo jurídico e psicológico.
